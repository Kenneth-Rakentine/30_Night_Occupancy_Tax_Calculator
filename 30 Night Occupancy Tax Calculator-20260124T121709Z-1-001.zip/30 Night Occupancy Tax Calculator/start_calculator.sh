#!/bin/bash

echo "========================================"
echo "  Hotel Occupancy Tax Calculator"
echo "  Starting..."
echo "========================================"
echo ""

# Start Python server in background
python3 app.py &
SERVER_PID=$!

# Wait for server to start
sleep 3

# Open browser (works on Mac and most Linux)
if command -v open &> /dev/null; then
    # Mac
    open http://localhost:5000
elif command -v xdg-open &> /dev/null; then
    # Linux
    xdg-open http://localhost:5000
else
    echo "Browser URL: http://localhost:5000"
fi

echo ""
echo "Browser opened! The calculator is running."
echo ""
echo "To STOP the calculator:"
echo "  Press Ctrl+C in this window"
echo ""
echo "========================================"

# Wait for Ctrl+C
trap "kill $SERVER_PID; exit" INT TERM
wait $SERVER_PID
