# Hotel Occupancy Tax Calculator - 100% FREE

A completely free, self-hosted web application for calculating hotel occupancy tax reimbursements after the 30th night of stay. No API costs, no subscriptions!

## Features

✅ **100% Free** - No API costs, runs entirely on your computer
✅ **PDF Auto-Extraction** - Upload hotel folios and automatically extract occupancy tax charges
✅ **30th Night Calculator** - Instantly calculate the 30th night from any arrival date
✅ **Tax Calculator** - Calculate total reimbursement with multiple line items
✅ **Open Source** - Uses free Tesseract OCR technology

## Installation

### Requirements
- Python 3.8 or higher
- Tesseract OCR (free, open-source)

### Windows Setup

1. **Install Python** (if not already installed)
   - Download from: https://www.python.org/downloads/
   - During installation, check "Add Python to PATH"

2. **Install Tesseract OCR**
   - Download from: https://github.com/UB-Mannheim/tesseract/wiki
   - Install to default location (C:\Program Files\Tesseract-OCR)

3. **Install Python packages**
   ```bash
   pip install flask pdfplumber pytesseract pillow
   ```

### Mac Setup

1. **Install Homebrew** (if not already installed)
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

2. **Install Tesseract and Python packages**
   ```bash
   brew install tesseract
   pip3 install flask pdfplumber pytesseract pillow
   ```

### Linux Setup

```bash
# Install Tesseract
sudo apt-get update
sudo apt-get install tesseract-ocr

# Install Python packages
pip3 install flask pdfplumber pytesseract pillow
```

## How to Run

1. **Open Terminal/Command Prompt** in the folder with these files

2. **Start the server**
   ```bash
   python app.py
   ```
   
   Or on Mac/Linux:
   ```bash
   python3 app.py
   ```

3. **Open your browser** to: http://localhost:5000

4. **To stop the server**: Press Ctrl+C in the terminal

## Usage

### Upload PDF Method (Recommended)
1. Click "Choose PDF File" or drag & drop your hotel folio
2. Wait 10-20 seconds for processing
3. Review extracted data (arrival date, occupancy taxes)
4. Verify the 30th night calculation
5. Check the total reimbursement amount

### Manual Entry Method
1. Enter the guest's arrival date
2. Click "+ Add Tax Line Item" for each occupancy tax amount
3. Enter: Tax Amount × Number of nights = Total
4. View the grand total reimbursement

## File Structure

```
hotel-tax-calculator/
├── app.py                           # Python backend server
├── hotel-tax-calculator-free.html   # Web interface
└── README.md                        # This file
```

## How It Works

1. **PDF Upload**: Converts PDF pages to images
2. **OCR Processing**: Uses Tesseract to extract text with positioning
3. **Smart Parsing**: Finds "Occupancy Tax" rows and extracts dates/amounts
4. **Data Validation**: Sorts by date, takes first 30 nights
5. **Auto-Population**: Fills calculator with grouped amounts

## Troubleshooting

### "Tesseract not found" error
- **Windows**: Make sure Tesseract is installed and add to PATH
- **Mac/Linux**: Run `brew install tesseract` or `sudo apt-get install tesseract-ocr`

### PDF extraction not working
- Try different PDF formats
- Ensure the PDF is not password-protected
- Check that "Occupancy Tax" appears clearly in the document

### Port already in use
- Change port in app.py: `app.run(debug=True, port=5001)`
- Then open: http://localhost:5001

## Technical Details

- **Backend**: Python Flask
- **PDF Processing**: pdfplumber (table extraction)
- **OCR**: Tesseract (open source)
- **Frontend**: HTML5, CSS3, JavaScript

## Cost Comparison

| Solution | Cost |
|----------|------|
| This App | **$0.00** (Forever!) |
| Claude API Version | ~$0.15 per PDF |
| Manual Calculation | Your time |

## Support

For issues or questions, check the console output when running `python app.py` to see detailed processing logs.

## License

Free to use for personal and commercial purposes.
