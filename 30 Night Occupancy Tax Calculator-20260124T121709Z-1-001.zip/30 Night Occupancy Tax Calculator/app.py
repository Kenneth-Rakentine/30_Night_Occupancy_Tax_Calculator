#!/usr/bin/env python3
"""
Hotel Occupancy Tax Calculator - Free OCR Backend
No API costs - uses Tesseract OCR (open source)
"""

from flask import Flask, request, jsonify, send_from_directory
import pdfplumber
import pytesseract
from PIL import Image
import io
import re
from datetime import datetime
from collections import defaultdict
import os

app = Flask(__name__)

def parse_date(date_str):
    """Parse date from various formats like 12-18-25, 12/18/25"""
    try:
        parts = re.split(r'[-/]', date_str)
        month = int(parts[0])
        day = int(parts[1])
        year = int(parts[2])
        
        if year < 100:
            year += 2000
        
        return datetime(year, month, day)
    except:
        return None

def extract_occupancy_taxes_from_pdf(pdf_file):
    """Extract occupancy tax charges from hotel folio PDF"""
    
    occupancy_taxes = []
    arrival_date = None
    guest_name = None
    
    try:
        with pdfplumber.open(pdf_file) as pdf:
            for page_num, page in enumerate(pdf.pages):
                print(f"Processing page {page_num + 1}...")
                
                # Extract text with layout preserved
                text = page.extract_text()
                
                if not text:
                    continue
                
                # Find guest name (only once, usually on first page)
                if not guest_name:
                    # Look for name pattern - usually first line with name before address
                    lines = text.split('\n')
                    for i, line in enumerate(lines):
                        # Guest name is typically before address line
                        # Look for a line that's not a date, not a header, before an address
                        if i < 20:  # Usually in first 20 lines
                            # Check if next line looks like an address
                            if i + 1 < len(lines):
                                next_line = lines[i + 1]
                                # Address usually has numbers and street names
                                if re.search(r'\d+\s+[A-Za-z]+\s+(St|Street|Ave|Avenue|Rd|Road|Dr|Drive|Ct|Court|Ln|Lane|Way|Place|Blvd|Boulevard)', next_line, re.IGNORECASE):
                                    # Current line is likely the name
                                    potential_name = line.strip()
                                    # Remove any extra text after the name (like "Folio No.", "Room No.", etc.)
                                    potential_name = re.split(r'\s+(Folio|Room|A/R|Group|Company|Membership|Invoice)', potential_name, flags=re.IGNORECASE)[0].strip()
                                    # Make sure it's not a header or company name
                                    if potential_name and not re.match(r'^(Date|Description|Charges|Credits)', potential_name, re.IGNORECASE):
                                        if len(potential_name.split()) >= 2 and len(potential_name) < 50:  # Names are typically 2+ words, under 50 chars
                                            guest_name = potential_name
                                            print(f"Found guest name: {guest_name}")
                                            break
                
                # Find arrival date (only once)
                if not arrival_date:
                    arrival_match = re.search(r'Arrival\s*:\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})', text, re.IGNORECASE)
                    if arrival_match:
                        arrival_date = parse_date(arrival_match.group(1))
                        print(f"Found arrival date: {arrival_date}")
                
                # Extract tables
                tables = page.extract_tables()
                
                for table in tables:
                    if not table:
                        continue
                    
                    for row in table:
                        if not row or len(row) < 2:
                            continue
                        
                        # Join all cells to search
                        row_text = ' '.join([str(cell) if cell else '' for cell in row])
                        
                        # Look for "Occupancy Tax" in the row (must be exact, not State Tax)
                        row_text_clean = row_text.strip()
                        
                        # Check if this row is specifically about Occupancy Tax (not State Tax)
                        if 'Occupancy Tax' in row_text_clean and 'State Tax' not in row_text_clean:
                            # Find date in this row
                            date_match = re.search(r'(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})', row_text)
                            
                            # Find amounts (format: X.XX)
                            amount_matches = re.findall(r'\b(\d{1,2}\.\d{2})\b', row_text)
                            
                            if date_match and amount_matches:
                                date = parse_date(date_match.group(1))
                                
                                # Get the last numeric value in the row (usually the amount column)
                                amounts = [float(amt) for amt in amount_matches if float(amt) > 0]
                                
                                if amounts and date:
                                    # Take the last amount (rightmost column)
                                    amt = amounts[-1]
                                    # Occupancy tax is typically $1-$15
                                    if 1.0 <= amt <= 15.0:
                                        occupancy_taxes.append({
                                            'date': date,
                                            'amount': amt
                                        })
                                        print(f"Found: {date.strftime('%m-%d-%y')} → ${amt}")
                                        break
                
                # Line-by-line parsing - works best for this format
                # Format: "12-18-25 Occupancy Tax 4.45"
                lines = text.split('\n')
                for line in lines:
                    # Match exact pattern: date + "Occupancy Tax" + amount
                    match = re.match(r'(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\s+Occupancy Tax\s+(\d{1,2}\.\d{2})', line.strip())
                    if match:
                        date = parse_date(match.group(1))
                        amount = float(match.group(2))
                        
                        if date and 1.0 <= amount <= 15.0:
                            occupancy_taxes.append({
                                'date': date,
                                'amount': amount
                            })
                            print(f"Found: {date.strftime('%m-%d-%y')} → ${amount}")
    
    except Exception as e:
        print(f"Error processing PDF: {e}")
        return None, None, None, str(e)
    
    # Remove duplicates based on date
    unique_taxes = {}
    for tax in occupancy_taxes:
        date_key = tax['date'].strftime('%Y-%m-%d')
        if date_key not in unique_taxes:
            unique_taxes[date_key] = tax
    
    # Sort by date
    sorted_taxes = sorted(unique_taxes.values(), key=lambda x: x['date'])
    
    # Take first 30 nights
    first_30 = sorted_taxes[:30]
    
    print(f"\nTotal found: {len(sorted_taxes)}, Using first 30: {len(first_30)}")
    
    # Convert dates to strings for JSON
    result = []
    for tax in first_30:
        result.append({
            'date': tax['date'].strftime('%m-%d-%y'),
            'amount': tax['amount']
        })
    
    arrival_str = arrival_date.strftime('%m-%d-%y') if arrival_date else None
    
    return arrival_str, result, guest_name, None

@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'hotel-tax-calculator-free.html')

@app.route('/process-pdf', methods=['POST'])
def process_pdf():
    """Process uploaded PDF and extract occupancy tax data"""
    
    if 'pdf' not in request.files:
        return jsonify({'success': False, 'error': 'No PDF file uploaded'}), 400
    
    pdf_file = request.files['pdf']
    
    if pdf_file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not pdf_file.filename.lower().endswith('.pdf'):
        return jsonify({'success': False, 'error': 'File must be a PDF'}), 400
    
    try:
        # Save to temporary file
        pdf_bytes = pdf_file.read()
        pdf_io = io.BytesIO(pdf_bytes)
        
        # Extract data
        arrival_date, occupancy_taxes, guest_name, error = extract_occupancy_taxes_from_pdf(pdf_io)
        
        if error:
            return jsonify({'success': False, 'error': error}), 500
        
        if not occupancy_taxes:
            return jsonify({
                'success': False, 
                'error': 'Could not find any occupancy tax charges in the PDF'
            }), 400
        
        total_amount = sum(tax['amount'] for tax in occupancy_taxes)
        
        return jsonify({
            'success': True,
            'arrivalDate': arrival_date,
            'guestName': guest_name,
            'occupancyTaxes': occupancy_taxes,
            'totalNights': len(occupancy_taxes),
            'totalAmount': round(total_amount, 2)
        })
    
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🏨 HOTEL OCCUPANCY TAX CALCULATOR")
    print("="*60)
    print("\n✅ Server starting...")
    print("📍 Open your browser to: http://localhost:5000")
    print("🆓 100% FREE - No API costs!")
    print("\n💡 To stop the server: Press Ctrl+C")
    print("="*60 + "\n")
    
    app.run(debug=True, port=5000)
