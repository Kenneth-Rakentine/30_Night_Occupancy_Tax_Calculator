# 🖥️ Desktop Setup Guide - One-Click Launch

## Quick Launch Options

I've created **3 easy ways** to run your calculator from your desktop:

---

## ✨ OPTION 1: Double-Click Launcher (EASIEST)

### Windows:
1. **Double-click `START_CALCULATOR.bat`**
   - Server starts automatically
   - Browser opens automatically
   - That's it! 🎉

### Mac/Linux:
1. **First time only**: Make the script executable
   ```bash
   chmod +x start_calculator.sh
   ```

2. **Double-click `start_calculator.sh`**
   - Server starts automatically
   - Browser opens automatically
   - Done! 🎉

**To stop**: Close the terminal window or press Ctrl+C

---

## 📌 OPTION 2: Desktop Shortcut

### Windows:
1. **Right-click** on `START_CALCULATOR.bat`
2. Select **"Send to" → "Desktop (create shortcut)"**
3. Now you have a desktop icon! 
4. **Double-click the desktop icon** anytime to launch

**Optional**: Change the icon:
- Right-click the shortcut → Properties
- Click "Change Icon"
- Choose any icon you like (hotel, calculator, etc.)

### Mac:
1. **Right-click** on `start_calculator.sh`
2. Select **"Make Alias"**
3. **Drag the alias** to your Desktop
4. **Double-click** to launch!

### Linux:
1. Create a `.desktop` file on your desktop:
   ```bash
   nano ~/Desktop/tax-calculator.desktop
   ```

2. Paste this (update the path to where you saved the files):
   ```
   [Desktop Entry]
   Name=Hotel Tax Calculator
   Comment=Occupancy Tax Calculator
   Exec=/path/to/start_calculator.sh
   Icon=calculator
   Terminal=true
   Type=Application
   ```

3. Make it executable:
   ```bash
   chmod +x ~/Desktop/tax-calculator.desktop
   ```

---

## 🌐 OPTION 3: Bookmark Launcher

1. **Open `OPEN_CALCULATOR.html` in your browser**
2. **Bookmark it** (Ctrl+D or Cmd+D)
3. **Drag the bookmark to your bookmarks bar** for easy access

**How it works:**
- Click the bookmark → Opens a nice launch page
- Click "Open Calculator" → Goes to the calculator
- If server isn't running, it tells you to start it first

**Pro tip**: You can also drag `OPEN_CALCULATOR.html` to your desktop for a clickable HTML icon!

---

## 🚀 OPTION 4: Windows Task Scheduler (Auto-start on boot)

Want it to start automatically when you log in?

1. Press **Win+R**, type `taskschd.msc`, press Enter
2. Click **"Create Basic Task"**
3. Name: "Hotel Tax Calculator"
4. Trigger: **"When I log on"**
5. Action: **"Start a program"**
6. Program: Browse to your `START_CALCULATOR.bat`
7. Finish!

Now it launches every time you log into Windows!

---

## 🎨 Make it Pretty - Custom Icons

### Windows Custom Icon:
1. Download a hotel/calculator icon (.ico file) from [icons8.com](https://icons8.com) or [flaticon.com](https://flaticon.com)
2. Right-click your desktop shortcut → Properties
3. Click "Change Icon" → Browse to your .ico file
4. Apply!

### Mac Custom Icon:
1. Find an image you like (hotel, calculator, etc.)
2. Copy the image (Cmd+C)
3. Right-click your shortcut → Get Info
4. Click the small icon in top-left
5. Paste (Cmd+V)
6. Close the window - your icon is changed!

---

## 📱 Quick Access Bar (Windows)

Pin to your taskbar for instant access:

1. Create your desktop shortcut (from Option 2)
2. **Right-click the shortcut**
3. Select **"Pin to taskbar"**
4. Now it's always in your taskbar! One click to launch!

---

## 🔧 Troubleshooting

**"Python is not recognized"**
- Add Python to your PATH, or use the full path in the batch file
- Edit `START_CALCULATOR.bat`, replace `python` with full path like:
  ```
  C:\Users\YourName\AppData\Local\Programs\Python\Python312\python.exe
  ```

**"Port 5000 already in use"**
- Edit `app.py`, change line at bottom:
  ```python
  app.run(debug=True, port=5001)  # Changed from 5000 to 5001
  ```
- Then use `http://localhost:5001` instead

**Mac/Linux: "Permission denied"**
- Run: `chmod +x start_calculator.sh`

---

## 📋 File Checklist

Make sure all these files are in the **same folder**:

```
📁 Hotel-Tax-Calculator/
  ├── 📄 app.py
  ├── 📄 hotel-tax-calculator-free.html
  ├── 🪟 START_CALCULATOR.bat (Windows)
  ├── 🐧 start_calculator.sh (Mac/Linux)
  ├── 🌐 OPEN_CALCULATOR.html
  └── 📖 README.md
```

---

## 🎯 Recommended Setup

**For easiest use:**

1. ✅ Put all files in: `C:\Hotel-Calculator\` (or `~/Hotel-Calculator/` on Mac)
2. ✅ Create desktop shortcut to `START_CALCULATOR.bat`
3. ✅ Give it a nice icon (hotel or calculator)
4. ✅ Pin to taskbar for instant access
5. ✅ Done! One-click launching! 🚀

---

## ⚡ Super Quick Start

**Literally 3 steps:**

1. Download all files to a folder
2. Double-click `START_CALCULATOR.bat` (Windows) or `start_calculator.sh` (Mac)
3. Use your calculator!

**That's it!** No command line needed after first setup! 🎊
